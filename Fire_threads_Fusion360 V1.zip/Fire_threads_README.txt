Fire threads for Autodesk Fusion 360
====================================
Files:
  Fire threads - GHT.xml    Garden / booster hose (ASME B1.20.7 3/4-11.5 NH + NHR)
  Fire threads - NH.xml     National Hose / NST / CHT (NFPA 1963; also includes GHT)
  Fire threads - NPSH.xml   National Pipe Straight Hose / IPT (ASME B1.20.7 + field sizes >4")
  Fire threads - NPT.xml    National Pipe Taper modeled as STRAIGHT (ASME B1.20.1 gauge-plane sizes)

Install (Windows)
  1. Close Fusion.
  2. Open:
     %localappdata%\Autodesk\webdeploy\production\
  3. Open the newest hash folder, then:
     Fusion\Server\Fusion\Configuration\ThreadData\
  4. Copy the four .xml files into ThreadData.
  5. Restart Fusion.
  6. Create > Thread > Thread Type:
       Fire threads - GHT
       Fire threads - NH
       Fire threads - NPSH
       Fire threads - NPT

After a Fusion update the production hash folder changes. Recopy the XMLs.

Naming
  Designation is "nominal TPI SERIES" e.g. 2.5-7.5 NH, 1.5-11.5 NPSH, 2.5-8 NPT.
  Size field is the nominal hose/pipe size Fusion uses to match a cylinder
  (0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 6).
  The modeled major diameter is the REAL male OD, not the nominal size.

Important modeling notes
  - NH and NPSH are STRAIGHT threads that seal on a gasket/washer.
  - NPT is TAPERED in the real world (1:16). Fusion's Thread command cannot
    model taper. This NPT family uses gauge-plane diameters so the thread
    LOOKS and MEASURES like NPT at the hand-tight plane. For a true taper
    use Coil + sweep or a lofted helix.
  - 3/4-8 NH and 1-8 NH share the same thread (1.375-8). Both designations
    are included so either nominal size finds the thread.
  - 1/2, 5/8, and 3/4 garden/booster GHT is 0.75-11.5 NH (male OD 1.0625).
  - 1-1/4 NH (1.25-9 NH, OD 1.6718) is uncommon but listed in coupling charts.
  - NPSH sizes above 4" are taken from fire-service identification charts
    (not full B1.20.7 tables) and are marked (field) in the designation.
  - Thread angle is 60 degrees for all families.
  - GHT / NHR live in Fire threads - GHT. Use 0.75 cylinder for standard 3/4 garden hose. NHR is the thin-wall formed variant (slightly smaller male major).
  - Printed parts: start with modeled threads as-is; if tight, scale 99-99.5%
    or offset faces 0.004-0.010 in. Gasket-sealed NH/NPSH can be a little loose.

Sources
  NFPA 1963 Table 5.4.1 (NH)
  ASME B1.20.7 (NPSH, 3/4-11.5 NH / NHR)
  ASME B1.20.1 (NPT basic / OD)
  Common US fire-hose identification charts (large NPSH, 2" NH, 1-1/4 NH)
